# Binance Futures Testnet Trading Bot

A simple CLI trading bot that places MARKET and LIMIT orders on Binance Futures Testnet.

## Setup

Clone the repo

Install dependencies

pip install -r requirements.txt

Set environment variables

export BINANCE_API_KEY=your_api_key
export BINANCE_API_SECRET=your_secret_key

## Run

Market Order

python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

Limit Order

python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 70000

## Features

✔ Market Orders  
✔ Limit Orders  
✔ BUY / SELL support  
✔ CLI validation  
✔ Logging  
✔ Error handling