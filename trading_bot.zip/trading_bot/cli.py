import argparse
from bot.client import get_client
from bot.orders import place_market_order, place_limit_order
from bot.validators import *
from bot.logging_config import setup_logging


def main():

    setup_logging()

    parser = argparse.ArgumentParser(
        description="Binance Futures Testnet Trading Bot"
    )

    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True)
    parser.add_argument("--type", required=True)
    parser.add_argument("--quantity", required=True)
    parser.add_argument("--price")

    args = parser.parse_args()

    try:

        symbol = args.symbol.upper()
        side = validate_side(args.side)
        order_type = validate_order_type(args.type)
        quantity = validate_quantity(args.quantity)
        price = validate_price(args.price)

        client = get_client()

        print("\nOrder Request Summary")
        print("-----------------------")
        print(f"Symbol: {symbol}")
        print(f"Side: {side}")
        print(f"Type: {order_type}")
        print(f"Quantity: {quantity}")
        if price:
            print(f"Price: {price}")

        if order_type == "MARKET":

            order = place_market_order(
                client, symbol, side, quantity
            )

        else:

            if price is None:
                raise ValueError("LIMIT order requires --price")

            order = place_limit_order(
                client, symbol, side, quantity, price
            )

        print("\nOrder Response")
        print("-----------------------")

        print("Order ID:", order.get("orderId"))
        print("Status:", order.get("status"))
        print("Executed Qty:", order.get("executedQty"))
        print("Avg Price:", order.get("avgPrice"))

        print("\nSUCCESS: Order placed successfully")

    except Exception as e:

        print("\nERROR:", e)


if __name__ == "__main__":
    main()