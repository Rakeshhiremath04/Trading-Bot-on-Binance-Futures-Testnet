import logging

def place_market_order(client, symbol, side, quantity):

    try:
        logging.info(f"Placing MARKET order {side} {symbol} qty={quantity}")

        response = client.futures_create_order(
            symbol=symbol,
            side=side,
            type="MARKET",
            quantity=quantity
        )

        logging.info(f"Market order response: {response}")

        return response

    except Exception as e:
        logging.error(f"Market order failed: {e}")
        raise


def place_limit_order(client, symbol, side, quantity, price):

    try:
        logging.info(
            f"Placing LIMIT order {side} {symbol} qty={quantity} price={price}"
        )

        response = client.futures_create_order(
            symbol=symbol,
            side=side,
            type="LIMIT",
            quantity=quantity,
            price=price,
            timeInForce="GTC"
        )

        logging.info(f"Limit order response: {response}")

        return response

    except Exception as e:
        logging.error(f"Limit order failed: {e}")
        raise