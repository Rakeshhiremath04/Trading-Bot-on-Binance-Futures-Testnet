import logging
from binance.client import Client
import os

API_KEY = "XXXXXXXXXXXXXXX"
API_SECRET ="XXXXXXXXXXXX"

TESTNET_URL = "https://testnet.binancefuture.com"

def get_client():
    try:
        client = Client(API_KEY, API_SECRET)
        client.FUTURES_URL = TESTNET_URL + "/fapi"

        logging.info("Connected to Binance Futures Testnet")
        return client

    except Exception as e:
        logging.error(f"Client creation failed: {e}")
        raise
print("API KEY:", API_KEY)
print("API SECRET:", API_SECRET)